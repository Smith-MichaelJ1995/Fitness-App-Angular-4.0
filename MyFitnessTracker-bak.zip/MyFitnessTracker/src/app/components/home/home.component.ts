import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user-service/user.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  constructor(public userService: UserService) {}

  ngOnInit() {
    //console.log('Is user logged in? ',this.user.getUserLoggedIn());
    //alert(this.user.getUserLoggedIn());
  }

}
